# CSE 337 "Configuration Management"

This project is part of the CSE 337 Software Engineering and Practice class offered at Oakland University.

In this repository, you will find the Beer Song project -- the project assigned to us to better understand git and further improve our Java capabilities.

The functionality specifications calls for the program to output the hit classic "99 Bottles of Beer" song to the terminal.